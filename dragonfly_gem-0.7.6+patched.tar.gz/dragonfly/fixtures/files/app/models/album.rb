class Album < ActiveRecord::Base
  image_accessor :cover_image
end