module Dragonfly
  puts "WARNING: Dragonfly::ImageMagickUtils is DEPRECATED and will soon be removed. Please use Dragonfly::ImageMagick::Utils instead."
  ImageMagickUtils = ImageMagick::Utils
end
